/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: quenalla <quenalla@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/09 12:26:58 by qacjl             #+#    #+#             */
/*   Updated: 2025/01/19 09:41:48 by quenalla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	init_collectables(t_game *game)
{
	int	y;
	int	x;

	y = 0;
	game->collectable = 0;
	while (y < game->map.height)
	{
		x = 0;
		while (x < game->map.width)
		{
			if (game->map.data[y][x] == 'C')
				game->collectable++;
			x++;
		}
		y++;
	}
	ft_printf("Total collectables: %d\n", game->collectable);
}

void	initialize_map(t_map *map)
{
	map->data = NULL;
	map->width = 0;
	map->height = 0;
}

int	close_game(t_game *game)
{
	mlx_destroy_window(game->mlx, game->window);
	exit (0);
	return (0);
}

int	main(int ac, char **av)
{
	t_game	game;

	if (ac != 2)
		return (write(2, "ERROR, ARGUMENT INCORRECT\n", 26), 1);
	initialize_map(&game.map);
	if (!validate_filename(av[1]))
		return (write(2, "ERROR, INCORRECT FILE\n", 22), 1);
	if (!read_map(av[1], &game.map))
		return (write(2, "ERROR, CANNOT READ MAP\n", 13), 1);
	if (!validate_map(&game.map))
		return (write(2, "ERROR, INVALID MAP\n", 19), 1);
	find_player_position(&game.map, &game.player_x, &game.player_y);
	init_collectables(&game);
	game.mlx = mlx_init();
	game.window = mlx_new_window(game.mlx, game.map.width * TILE_SIZE,
			game.map.height * TILE_SIZE, WINDOW_TITLE);
	game.steps = 0;
	init_texture(&game);
	render_map(&game);
	mlx_key_hook(game.window, handle_input, &game);
	mlx_hook(game.window, 17, 0, close_game, &game);
	mlx_loop(game.mlx);
	free_game(&game);
	return (0);
}
