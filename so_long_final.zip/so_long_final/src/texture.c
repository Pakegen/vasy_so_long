/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   texture.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: quenalla <quenalla@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/19 08:11:00 by quenalla          #+#    #+#             */
/*   Updated: 2025/01/19 09:45:20 by quenalla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

/*
int	test_texture(t_game game)
{
	if (!(game->floor_img))
}*/

/*void	load_sprite(t_game *game, const char *path)
{
	int	sprite_width;
	int	sprite_height;

	sprite_width = 0;
	sprite_height = 0;
	game->floor_img = mlx_xpm_file_to_image(game->mlx,
			"texture/BACKGROUND.xpm", &sprite_width, &sprite_height);
	game->wall_img = mlx_xpm_file_to_image(game->mlx,
			"texture/WALL.xpm", &sprite_width, &sprite_height);
	game->player_down = mlx_xpm_file_to_image(game->mlx,
			"texture/slime_down.xpm", &sprite_width, &sprite_height);
	game->player_left = mlx_xpm_file_to_image(game->mlx,
			"texture/slime_left.xpm", &sprite_width, &sprite_height);
	game->player_up = mlx_xpm_file_to_image(game->mlx,
			"texture/slime_up.xpm", &sprite_width, &sprite_height);
	game->player_right = mlx_xpm_file_to_image(game->mlx,
			"texture/slime_right.xpm", &sprite_width, &sprite_height);
	game->current_player_img = mlx_xpm_file_to_image(game->mlx,
			"texture/slime_right.xpm", &sprite_width, &sprite_height);
	game->collect_img = mlx_xpm_file_to_image(game->mlx,
			"texture/piece.xpm", &sprite_width, &sprite_height);
	game->exit_img = mlx_xpm_file_to_image(game->mlx,
			"texture/exit.xpm", &sprite_height, &sprite_height);
}*/

static void	*load_sprite(t_game *game, const char *path)
{
	void	*texture;
	int		width;
	int		height;

	width = 0;
	height = 0;
	if (!game || !game->mlx || !path)
		return (NULL);
	texture = mlx_xpm_file_to_image(game->mlx, (char *)path, &width, &height);
	if (!texture)
	{
		write(2, "Error, Failed to load texture\n", 31);
		free_game(game);
		exit(EXIT_FAILURE);
	}
	return (texture);
}


static	void	load_all_texture(t_game *game)
{
	game->texture[TEXTURE_PLAYER_TOP] = load_sprite(game,
			"texture/slime_up.xpm");
	game->texture[TEXTURE_PLAYER_RIGHT] = load_sprite(game,
			"texture/slime_right.xpm");
	game->texture[TEXTURE_PLAYER_DOWN] = load_sprite(game,
			"texture/slime_down.xpm");
	game->texture[TEXTURE_PLAYER_LEFT] = load_sprite(game,
			"texture/slime_left.xpm");
	game->texture[TEXTURE_WALL] = load_sprite(game,
			"texture/WALL.xpm");
	game->texture[TEXTURE_BACKGROUND] = load_sprite(game,
			"texture/BACKGROUND.xpm");
	game->texture[TEXTURE_EXIT] = load_sprite(game,
			"texture/exit.xpm");
	game->texture[TEXTURE_COLLECTIBLE] = load_sprite(game,
			"texture/piece.xpm");
}

int	init_texture(t_game *game)
{
	if (!game || !game->mlx)
		return (0);
	game->texture = malloc(sizeof(void *) * TEXTURE_COUNT);
	if (!game->texture)
		return (write(2, "ERROR MEMORY TEXTURE FAILED\n", 29), 0);
	load_all_texture(game);
	return (1);
}
