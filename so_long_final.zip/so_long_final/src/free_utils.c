/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free_utils.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: quenalla <quenalla@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/19 08:50:58 by quenalla          #+#    #+#             */
/*   Updated: 2025/01/19 11:11:26 by quenalla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

static void	free_map_data(char **data, int x)
{
	int	i;

	if (!data)
		return ;
	i = 0;
	while (i < x)
	{
		if (data[i])
			free(data[i]);
		i++;
	}
	free(data);
}

void	free_map(t_map *map)
{
	if (!map)
		return ;
	if (map->data)
		free_map_data(map->data, map->width);
}

void	free_textures(t_game *game)
{
	int	i;

	if (!game || !game->texture)
		return ;
	i = 0;
	while (i < TEXTURE_COUNT)
	{
		if (game->texture[i])
			free(game->texture[i]);
		i++;
	}
	free(game->texture);
}

void	free_mlx(t_game *game)
{
	if (!game || !game->mlx)
		return ;
	mlx_destroy_display(game->mlx);
	free(game->mlx);
}

void	free_game(t_game *game)
{
	if (!game)
		return ;
	free_map(&game->map);
	free_textures(game);
	free_mlx(game);
	free(game);
}
