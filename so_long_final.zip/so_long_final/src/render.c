/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   render.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: quenalla <quenalla@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 14:07:11 by qacjl             #+#    #+#             */
/*   Updated: 2025/01/19 10:45:03 by quenalla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"so_long.h"

void	render_tile(t_game *game, int y, int x)
{
	void	*img;

	img = game->texture[TEXTURE_BACKGROUND];
	if (game->map.data[y][x] == '1')
		img = game->texture[TEXTURE_WALL];
	else if (game->map.data[y][x] == 'C')
		img = game->texture[TEXTURE_COLLECTIBLE];
	else if (game->map.data[y][x] == 'E')
		img = game->texture[TEXTURE_EXIT];
	mlx_put_image_to_window(game->mlx, game->window, img, x * TILE_SIZE,
		y * TILE_SIZE);
}

void	render_map(t_game *game)
{
	int	y;
	int	x;

	y = 0;
	while (y < game->map.height)
	{
		x = 0;
		while (x < game->map.width)
		{
			render_tile(game, y, x);
			x++;
		}
		y++;
	}
	mlx_put_image_to_window(game->mlx, game->window,
		game->texture[CURRENT_PLAYER],
		game->player_x * TILE_SIZE,
		game->player_y * TILE_SIZE);
}
